package Appointment;

import java.util.Date;

public class Appointment {
    private final String appointmentId;
    private final Date appointmentDate;
    private final String description;

    public Appointment(String appointmentId, Date appointmentDate, String description) {
        if (appointmentId == null || appointmentId.length() > 10) 
            throw new IllegalArgumentException("Invalid appointment ID: must be non-null and at most 10 characters.");
        if (appointmentDate == null || appointmentDate.before(new Date())) 
            throw new IllegalArgumentException("Invalid appointment date: must be a future date.");
        if (description == null || description.length() > 50) 
            throw new IllegalArgumentException("Invalid description: must be non-null and at most 50 characters.");

        this.appointmentId = appointmentId;
        this.appointmentDate = new Date(appointmentDate.getTime()); // Ensure immutability
        this.description = description;
    }

    public String getAppointmentId() {
        return appointmentId;
    }

    public Date getAppointmentDate() {
        return new Date(appointmentDate.getTime()); // Ensure immutability
    }

    public String getDescription() {
        return description;
    }
}
