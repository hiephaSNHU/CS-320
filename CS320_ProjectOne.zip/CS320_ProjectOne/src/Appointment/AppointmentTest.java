package Appointment;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentTest {

    @Test
    public void testValidAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000); // 1 day in the future
        Appointment appointment = new Appointment("12345", futureDate, "Meeting");
        assertEquals("12345", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Meeting", appointment.getDescription());
    }

    @Test
    public void testInvalidAppointmentId() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        assertThrows(IllegalArgumentException.class, () -> new Appointment(null, futureDate, "Meeting"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345678901", futureDate, "Meeting"));
    }

    @Test
    public void testInvalidAppointmentDate() {
        Date pastDate = new Date(System.currentTimeMillis() - 86400000); // 1 day in the past
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345", pastDate, "Meeting"));
    }

    @Test
    public void testInvalidDescription() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345", futureDate, null));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345", futureDate, "This description is far too long to be valid in this context."));
    }
}
