package Appointment;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentServiceTest {
    private AppointmentService service;

    @BeforeEach
    public void setup() {
        service = new AppointmentService();
    }

    @Test
    public void testAddAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000); // 1 day in the future
        Appointment appointment = new Appointment("12345", futureDate, "Meeting");
        service.addAppointment(appointment);
        assertEquals(appointment, service.getAppointment("12345"));
    }

    @Test
    public void testAddDuplicateAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        Appointment appointment = new Appointment("12345", futureDate, "Meeting");
        service.addAppointment(appointment);
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(appointment));
    }

    @Test
    public void testDeleteAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        Appointment appointment = new Appointment("12345", futureDate, "Meeting");
        service.addAppointment(appointment);
        service.deleteAppointment("12345");
        assertNull(service.getAppointment("12345"));
    }

    @Test
    public void testDeleteNonExistentAppointment() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment("12345"));
    }

    @Test
    public void testGetNonExistentAppointment() {
        assertNull(service.getAppointment("12345"));
    }

    @Test
    public void testAddNullAppointment() {
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(null));
    }

    @Test
    public void testGetAppointmentWithNullId() {
        assertThrows(IllegalArgumentException.class, () -> service.getAppointment(null));
    }

    @Test
    public void testDeleteAppointmentWithNullId() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment(null));
    }
}
