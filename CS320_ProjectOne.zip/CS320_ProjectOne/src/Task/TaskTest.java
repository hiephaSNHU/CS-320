package Task;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    public void testValidTask() {
        Task task = new Task("12345", "Task Name", "Task Description");
        assertEquals("12345", task.getUniqueID());
        assertEquals("Task Name", task.getName());
        assertEquals("Task Description", task.getDescription());
    }

    @Test
    public void testInvalidUniqueID() {
        // Test invalid Unique ID (null)
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "Task Name", "Task Description"));

        // Test invalid Unique ID (too long)
        assertThrows(IllegalArgumentException.class, () -> new Task("12345678901", "Task Name", "Task Description"));
    }

    @Test
    public void testInvalidName() {
        // Test invalid name (null)
        assertThrows(IllegalArgumentException.class, () -> new Task("12345", null, "Task Description"));

        // Test invalid name (too long)
        assertThrows(IllegalArgumentException.class, () -> new Task("12345", "A very long task name", "Task Description"));

        // Test invalid name (empty string)
        assertThrows(IllegalArgumentException.class, () -> new Task("12345", "", "Task Description"));
    }

    @Test
    public void testInvalidDescription() {
        // Test invalid description (null)
        assertThrows(IllegalArgumentException.class, () -> new Task("12345", "Task Name", null));

        // Test invalid description (too long)
        assertThrows(IllegalArgumentException.class, () -> new Task("12345", "Task Name", "A very long description that exceeds fifty characters."));

        // Test invalid description (empty string)
        assertThrows(IllegalArgumentException.class, () -> new Task("12345", "Task Name", ""));
    }
}
