package Task;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    private TaskService service;

    @BeforeEach
    public void setup() {
        service = new TaskService();
    }

    @Test
    public void testAddTask() {
        Task task = new Task("12345", "Task Name", "Task Description");
        service.addTask(task);
        assertEquals(task, service.getTask("12345"));
    }

    @Test
    public void testAddDuplicateTask() {
        Task task = new Task("12345", "Task Name", "Task Description");
        service.addTask(task);
        assertThrows(IllegalArgumentException.class, () -> service.addTask(task));
    }

    @Test
    public void testDeleteTask() {
        Task task = new Task("12345", "Task Name", "Task Description");
        service.addTask(task);
        service.deleteTask("12345");
        assertNull(service.getTask("12345"));
    }

    @Test
    public void testDeleteNonExistentTask() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteTask("12345"));
    }

    @Test
    public void testUpdateTask() {
        Task task = new Task("12345", "Task Name", "Task Description");
        service.addTask(task);

        // Update task name and description
        service.updateTask("12345", "Updated Task Name", "Updated Task Description");
        Task updatedTask = service.getTask("12345");
        assertEquals("Updated Task Name", updatedTask.getName());
        assertEquals("Updated Task Description", updatedTask.getDescription());
    }

    @Test
    public void testUpdateNonExistentTask() {
        assertThrows(IllegalArgumentException.class, () -> service.updateTask("12345", "Updated Task Name", "Updated Task Description"));
    }
}
