package Task;

import java.util.HashMap;
import java.util.Map;

public class TaskService {

    private final Map<String, Task> tasks = new HashMap<>();

    // Add a task
    public void addTask(Task task) {
        if (tasks.containsKey(task.getUniqueID())) {
            throw new IllegalArgumentException("Task ID already exists");
        }
        tasks.put(task.getUniqueID(), task);
    }

    // Delete a task by ID
    public void deleteTask(String uniqueID) {
        if (!tasks.containsKey(uniqueID)) {
            throw new IllegalArgumentException("Task not found");
        }
        tasks.remove(uniqueID);
    }

    // Update a task
    public void updateTask(String uniqueID, String name, String description) {
        Task task = tasks.get(uniqueID);
        if (task == null) {
            throw new IllegalArgumentException("Task not found");
        }

        if (name != null) task.setName(name);
        if (description != null) task.setDescription(description);
    }

    // Get a task by ID
    public Task getTask(String uniqueID) {
        return tasks.get(uniqueID);
    }
}
