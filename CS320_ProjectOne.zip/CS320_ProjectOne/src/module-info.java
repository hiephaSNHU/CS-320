/**
 * 
 */
/**
 * 
 */
module CS320_ProjectOne {
	requires org.junit.jupiter.api;
}