package Contact;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {
    
    private ContactService service;

    @BeforeEach
    public void setup() {
        service = new ContactService();
    }

    @Test
    public void testAddContact() {
        // Test adding a valid contact
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Street");
        service.addContact(contact);

        // Ensure the contact was added correctly
        assertEquals(contact, service.getContact("12345"));
    }

    @Test
    public void testAddDuplicateContact() {
        // Test adding a contact with a duplicate ID
        Contact contact1 = new Contact("12345", "John", "Doe", "1234567890", "123 Street");
        service.addContact(contact1);

        // Should throw an exception when trying to add the same contact again
        assertThrows(IllegalArgumentException.class, () -> service.addContact(contact1));
    }

    @Test
    public void testDeleteContact() {
        // Test deleting a contact
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Street");
        service.addContact(contact);
        service.deleteContact("12345");

        // Ensure the contact was deleted
        assertNull(service.getContact("12345"));
    }

    @Test
    public void testDeleteNonExistentContact() {
        // Test deleting a contact that doesn't exist
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact("12345"));
    }

    @Test
    public void testUpdateContact() {
        // Test updating an existing contact
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Street");
        service.addContact(contact);

        // Update the contact's details
        service.updateContact("12345", "Jane", null, null, null);

        // Verify the updated fields
        assertEquals("Jane", service.getContact("12345").getFirstName());
        assertEquals("Doe", service.getContact("12345").getLastName());
    }

    @Test
    public void testUpdateNonExistentContact() {
        // Test updating a non-existent contact
        assertThrows(IllegalArgumentException.class, () -> service.updateContact("12345", "Jane", "Doe", "0987654321", "New Address"));
    }
}
