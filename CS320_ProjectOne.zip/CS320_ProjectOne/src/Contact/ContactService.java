package Contact;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private final Map<String, Contact> contacts = new HashMap<>();

    // Add a new contact to the service
    public void addContact(Contact contact) {
        if (contacts.containsKey(contact.getContactID())) {
            throw new IllegalArgumentException("Contact ID already exists");
        }
        contacts.put(contact.getContactID(), contact);
    }

    // Delete a contact by ID
    public void deleteContact(String contactID) {
        if (!contacts.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact not found");
        }
        contacts.remove(contactID);
    }

    // Update an existing contact's details
    public void updateContact(String contactID, String firstName, String lastName, String phoneNumber, String address) {
        Contact contact = contacts.get(contactID);
        if (contact == null) {
            throw new IllegalArgumentException("Contact not found");
        }

        // Update details only if they are not null
        if (firstName != null) contact.setFirstName(firstName);
        if (lastName != null) contact.setLastName(lastName);
        if (phoneNumber != null) contact.setPhoneNumber(phoneNumber);
        if (address != null) contact.setAddress(address);
    }

    // Retrieve a contact by ID
    public Contact getContact(String contactID) {
        return contacts.get(contactID);
    }
}
