package Contact;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    public void testValidContact() {
        // Create a valid contact and check its attributes
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Street");
        assertEquals("12345", contact.getContactID());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("1234567890", contact.getPhoneNumber());
        assertEquals("123 Street", contact.getAddress());
    }

    @Test
    public void testInvalidContactIDTooLong() {
        // Test for invalid contactID (too long)
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345678901", "John", "Doe", "1234567890", "123 Street"));
    }

    @Test
    public void testInvalidFirstNameTooLong() {
        // Test for invalid first name (too long)
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345", "JohnJohnJohn", "Doe", "1234567890", "123 Street"));
    }

    @Test
    public void testInvalidPhoneNumber() {
        // Test for invalid phone number (not 10 digits)
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345", "John", "Doe", "12345", "123 Street"));
    }

    @Test
    public void testInvalidAddressTooLong() {
        // Test for invalid address (too long)
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345", "John", "Doe", "1234567890", "123456789012345678901234567890123"));
    }
}
